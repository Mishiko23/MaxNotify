<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'name' => 'MaxNotify',
    'author' => 'Mishiko23',
    'email' => 'bigo2008@gmail.com',
    'description' => 'Уведомления о заказах miniShop2 в MAX через официальный MAX Business API или сервис rumaxbot.ru.',
    'license' => 'MIT License

Copyright (c) 2026 Mishiko23 <bigo2008@gmail.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# MaxNotify для miniShop2

![MaxNotify — уведомления miniShop2 в MAX](docs/maxnotify-cover.png)

**MaxNotify** — компонент для MODX Revolution 2, который отправляет сведения
о заказах miniShop2 в мессенджер MAX через официальный
[MAX Business API](https://dev.max.ru/docs/maxbusiness/connection) или сервис
[rumaxbot.ru](https://rumaxbot.ru).

Компонент помогает владельцу и менеджерам интернет-магазина быстро узнавать
о новых заказах и изменениях их статуса без постоянной проверки панели MODX.

## Автор

- Разработчик: **Mishiko23**
- Email: **bigo2008@gmail.com**

## Возможности

- уведомление сразу после создания заказа miniShop2;
- уведомление при изменении статуса заказа;
- уведомления о заявках FormIt;
- уведомления о заявках SendIt;
- отдельное отключение источников miniShop2, FormIt и SendIt;
- фильтрация уведомлений по ID статусов;
- номер, сумма и состав заказа;
- имя, телефон и email покупателя;
- адрес доставки и комментарий клиента;
- название способа доставки и оплаты;
- ссылка на конкретный заказ в панели MODX;
- официальный MAX Business API и сервис rumaxbot.ru на выбор;
- отправка одному или нескольким чатам, каналам или пользователям;
- сообщения в формате Markdown или HTML;
- редактируемые чанки сообщений;
- запись ошибок API и соединения в журнал MODX.

## Требования

- MODX Revolution 2.8+;
- miniShop2 2.x или 4.x;
- PHP 7.2+;
- PHP cURL или включённый `allow_url_fopen`;
- токен официального MAX-бота или канал и API-ключ rumaxbot.ru.

Компонент проверен с MODX Revolution 2.8.8-pl и miniShop2 4.4.2-pl.

## Установка

1. Откройте в MODX раздел **Пакеты → Установщик**.
2. Найдите компонент **MaxNotify** в репозитории
   [modstore.pro](https://modstore.pro).
3. Нажмите **Скачать**, затем **Установить**.
4. После установки очистите кэш MODX.

## Настройка

Откройте **Системные настройки** и выберите пространство имён `maxnotify`.

Основные параметры:

- `maxnotify.enabled` — включает или отключает компонент;
- `maxnotify.enable_minishop2` — уведомления miniShop2;
- `maxnotify.enable_formit` — уведомления FormIt;
- `maxnotify.enable_sendit` — уведомления SendIt;
- `maxnotify.provider` — `rumaxbot` или `maxbusiness`;
- `maxnotify.format` — формат `markdown` или `html`;
- `maxnotify.timeout` — таймаут API-запроса в секундах;
- `maxnotify.notify_new_order` — уведомления о новых заказах;
- `maxnotify.notify_status_change` — уведомления о смене статуса;
- `maxnotify.statuses` — ID статусов через запятую, пустое поле разрешает все;
- `maxnotify.form_exclude_fields` — технические поля форм, которые не нужно отправлять;
- `maxnotify.form_field_labels` — русские названия полей форм в формате `field=Название`.

## Подключение FormIt

Добавьте hook-сниппет `maxNotifyFormIt` в параметр `&hooks` после успешных
проверок формы.

Пример:

```html
[[!FormIt?
    &hooks=`spam,email,maxNotifyFormIt,redirect`
    &emailTpl=`tpl.Email`
    &redirectTo=`12`
]]
```

Отключить отправку заявок FormIt можно настройкой `maxnotify.enable_formit`.
Заголовок сообщения меняется настройкой `maxnotify.formit_title`.

## Подключение SendIt

Добавьте hook-сниппет `maxNotifySendIt` в цепочку успешной обработки SendIt,
если в вашей конфигурации SendIt используются hook-сниппеты. Сниппет также
умеет брать данные из `$_POST`, поэтому его можно вызывать после успешной
валидации формы.

Отключить отправку заявок SendIt можно настройкой `maxnotify.enable_sendit`.
Заголовок сообщения меняется настройкой `maxnotify.sendit_title`.

## Названия полей форм

По умолчанию MaxNotify показывает частые поля по-русски:

- `name` → `Имя`;
- `phone` → `Телефон`;
- `email` → `Email`;
- `message` → `Сообщение`;
- `comment` → `Комментарий`.

Свои названия можно задать в настройке `maxnotify.form_field_labels`, например:

```text
name=Имя,phone=Телефон,email=Email,service=Услуга
```

Служебные поля вроде `agree`, `pageId`, `nospam` и `nospam:blank`
исключаются настройкой `maxnotify.form_exclude_fields`.

## Подключение официального MAX Business API

Официальное подключение доступно верифицированным организациям и ИП,
которые являются резидентами РФ.

1. Создайте и верифицируйте профиль на
   [платформе MAX для партнёров](https://business.max.ru).
2. Создайте чат-бота и дождитесь прохождения модерации.
3. Получите токен в разделе **Чат-боты → Перейти → Расширенные настройки →
   Настроить**.
4. Добавьте бота в нужный чат или канал либо запустите личный диалог с ботом.
5. Получите `chat_id` или `user_id` через Webhook/Long Polling API MAX.
6. Установите `maxnotify.provider` в значение `maxbusiness`.
7. Заполните настройки:
   - `maxnotify.max_token` — токен бота;
   - `maxnotify.max_ca_cert_path` — необязательный путь к PEM-файлу/CA bundle
     с сертификатом Минцифры;
   - `maxnotify.max_recipient_type` — `chat_id` или `user_id`;
   - `maxnotify.max_recipient_ids` — один или несколько ID через запятую;
   - `maxnotify.max_notify` — уведомлять участников чата;
   - `maxnotify.max_disable_link_preview` — отключить превью ссылок.

Официальный API принимает сообщения длиной до 4000 символов. Более длинные
уведомления MaxNotify автоматически сокращает.

С 19 июля 2026 MAX требует отправлять запросы на домен
`platform-api2.max.ru` вместо `platform-api.max.ru` и добавить сертификат
Минцифры в список доверенных. В MaxNotify новый домен используется по
умолчанию. Если на сервере PHP/cURL не доверяет сертификату системно,
укажите путь к PEM-файлу или CA bundle в настройке
`maxnotify.max_ca_cert_path`.

## Подключение rumaxbot.ru

Установите `maxnotify.provider` в значение `rumaxbot`, затем укажите:

- `maxnotify.api_key` — API-ключ канала rumaxbot.ru;
- `maxnotify.api_url` — адрес API отправки сообщений;

1. Зарегистрируйтесь на rumaxbot.ru и подтвердите email.
2. Создайте канал.
3. Подключите MAX-бота к каналу по инструкции сервиса.
4. Создайте API-ключ канала.
5. Укажите ключ в настройке `maxnotify.api_key`.

API-ключ нельзя публиковать или добавлять в репозиторий.

## Шаблоны сообщений

После установки в категории элементов `MaxNotify` будут созданы чанки:

- `maxNotifyOrderCreated` — новый заказ в Markdown;
- `maxNotifyOrderStatus` — новый статус в Markdown;
- `maxNotifyOrderCreatedHtml` — новый заказ в HTML;
- `maxNotifyOrderStatusHtml` — новый статус в HTML;
- `maxNotifyForm` — заявка с формы в Markdown;
- `maxNotifyFormHtml` — заявка с формы в HTML.

Доступные плейсхолдеры: `num`, `cost`, `receiver`, `phone`, `email`,
`address`, `comment`, `order_comment`, `products`, `delivery_name`,
`payment_name`, `status_name`, `manager_url`, `source`, `title`, `fields`,
`resource_id`, `resource_pagetitle`, `ip` и другие поля заказа или формы.
',
    'changelog' => '# История изменений MaxNotify

## 1.2.2-pl

- обновлена сигнатура установочного пакета, чтобы MODX не использовал ранее распакованные vehicle-файлы версии `1.2.1-pl`;
- исправлена ошибка установки из каталога `core/packages/maxnotify-1.2.1-pl/modCategory/`.

## 1.2.1-pl

- добавлены русские названия полей форм по умолчанию;
- добавлена настройка `maxnotify.form_field_labels` для переименования полей форм;
- расширен список технических полей, исключаемых из уведомлений;
- исправлена фильтрация составных полей вроде `nospam:blank`.

## 1.2.0-pl

- добавлены уведомления о заявках FormIt через hook-сниппет `maxNotifyFormIt`;
- добавлены уведомления о заявках SendIt через hook-сниппет `maxNotifySendIt`;
- добавлен общий шаблон заявки `maxNotifyForm` и HTML-версия `maxNotifyFormHtml`;
- добавлены отдельные переключатели источников `maxnotify.enable_minishop2`, `maxnotify.enable_formit`, `maxnotify.enable_sendit`;
- добавлен список исключаемых технических полей формы `maxnotify.form_exclude_fields`;
- добавлены отдельные заголовки уведомлений FormIt и SendIt.

## 1.1.1-pl

- обновлён официальный endpoint MAX Business API на `https://platform-api2.max.ru/messages`;
- добавлена миграция старого значения `platform-api.max.ru` при обновлении пакета;
- добавлена настройка `maxnotify.max_ca_cert_path` для PEM-файла/CA bundle с сертификатом Минцифры;
- обновлена документация по требованию MAX перейти на новый домен до 19 июля 2026.

## 1.1.0-pl

- добавлена прямая интеграция с официальным MAX Business API;
- добавлен выбор провайдера между MAX Business и rumaxbot.ru;
- добавлена отправка в чат, канал или пользователю по `chat_id`/`user_id`;
- добавлена отправка нескольким получателям;
- учтено ограничение официального API в 4000 символов;
- сохранена обратная совместимость с настройками rumaxbot.ru.

## 1.0.1-pl

- добавлены данные доставки, оплаты и полный адрес заказа;
- ссылка в сообщении ведёт непосредственно на заказ в MODX.

## 1.0.0-pl

- первая версия компонента;
- уведомления о новых заказах miniShop2;
- уведомления об изменении статусов;
- интеграция с API rumaxbot.ru;
- шаблоны Markdown и HTML.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '59ec85e42a332c2d6f127f41cd8b0e92',
      'native_key' => 'maxnotify',
      'filename' => 'modNamespace/14803357fe2a8d402fe5f720b9cef16c.vehicle',
      'namespace' => 'maxnotify',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4a93d6804fb7220faff24b6398f4cfeb',
      'native_key' => NULL,
      'filename' => 'modCategory/e82a3611eb87d5785fd64a5cfa5a43ae.vehicle',
      'namespace' => 'maxnotify',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '872b202d331b43cc5115554125625b69',
      'native_key' => 'maxnotify.enabled',
      'filename' => 'modSystemSetting/daeea1733195567818b2fefde775025c.vehicle',
      'namespace' => 'maxnotify',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a34620de38c61591890d477e7f748ad4',
      'native_key' => 'maxnotify.enable_minishop2',
      'filename' => 'modSystemSetting/08a5086e242f1beabf57c411f8b177aa.vehicle',
      'namespace' => 'maxnotify',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd9ef7e0231ae0aab2833a3da8ed6912',
      'native_key' => 'maxnotify.enable_formit',
      'filename' => 'modSystemSetting/772a1eb87ddcc2769a2a7f7f2463387e.vehicle',
      'namespace' => 'maxnotify',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e18ae564a6853b612e9cb81d39af218e',
      'native_key' => 'maxnotify.enable_sendit',
      'filename' => 'modSystemSetting/7f56ce87fb664b0d46be5eb67e1843ea.vehicle',
      'namespace' => 'maxnotify',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98dbf471faa74d0c3b29cbcd18853a1c',
      'native_key' => 'maxnotify.provider',
      'filename' => 'modSystemSetting/3f0f224c6184002963b0bbe7c89b252e.vehicle',
      'namespace' => 'maxnotify',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c97d47519b39d0f084e31b43f8247a6',
      'native_key' => 'maxnotify.api_url',
      'filename' => 'modSystemSetting/9632028f61f1b085c728d0dd2ed15001.vehicle',
      'namespace' => 'maxnotify',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a607e39afcbd3460a46b30645d4f5c1',
      'native_key' => 'maxnotify.api_key',
      'filename' => 'modSystemSetting/c0cf045ebf7e9cfbad8f7598eee048ce.vehicle',
      'namespace' => 'maxnotify',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13ae506babe3c4de7b55bf61e7fef32b',
      'native_key' => 'maxnotify.max_api_url',
      'filename' => 'modSystemSetting/3f4f9357956a082bb6d6073bea4264af.vehicle',
      'namespace' => 'maxnotify',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e96279dd8010373c667f4e6e06ee2cb',
      'native_key' => 'maxnotify.max_token',
      'filename' => 'modSystemSetting/1dc27789969e88e51de058cb4d8a5b9a.vehicle',
      'namespace' => 'maxnotify',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '722774633b5a938899125a50b6637bb0',
      'native_key' => 'maxnotify.max_ca_cert_path',
      'filename' => 'modSystemSetting/bf701a220f6663c60154c0315dad9d72.vehicle',
      'namespace' => 'maxnotify',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e947d43eabae48b22fb9b74cb7fe8ff',
      'native_key' => 'maxnotify.max_recipient_type',
      'filename' => 'modSystemSetting/c775c8da298fc07aa30a939f7c6430b3.vehicle',
      'namespace' => 'maxnotify',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0066a0337e4157bb469912e32dea1f11',
      'native_key' => 'maxnotify.max_recipient_ids',
      'filename' => 'modSystemSetting/e0c4e9cdd87658bc8dafb2001769d70f.vehicle',
      'namespace' => 'maxnotify',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'abc60ce5d22d571e9b9da6c1533bb27c',
      'native_key' => 'maxnotify.max_notify',
      'filename' => 'modSystemSetting/255da9479c4be845244c7fde3f963a6d.vehicle',
      'namespace' => 'maxnotify',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '744d76704cb4b3528e782ffc69838baf',
      'native_key' => 'maxnotify.max_disable_link_preview',
      'filename' => 'modSystemSetting/b4fdefae124aa3fe9c182e16e4a576f0.vehicle',
      'namespace' => 'maxnotify',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fae0be7f3d1ecdb89c73284fc1d87b2d',
      'native_key' => 'maxnotify.format',
      'filename' => 'modSystemSetting/8147446cc1965a5d362eaaefe0e672af.vehicle',
      'namespace' => 'maxnotify',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c6de28de32fb8f70cf3efad6a4ce3d3',
      'native_key' => 'maxnotify.timeout',
      'filename' => 'modSystemSetting/aa11178e1c78f2386fe71e431c4dc552.vehicle',
      'namespace' => 'maxnotify',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21bb7dacd1aa3f2dabc246849afb4075',
      'native_key' => 'maxnotify.notify_new_order',
      'filename' => 'modSystemSetting/a3cea681019c9f2eb1b809ba00fe865a.vehicle',
      'namespace' => 'maxnotify',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f56b67a0711333418535c7ce9a804bb4',
      'native_key' => 'maxnotify.notify_status_change',
      'filename' => 'modSystemSetting/1cbd0c34268b8518aecc17cacc0eea42.vehicle',
      'namespace' => 'maxnotify',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcf560d5f697ba15f6a9f2c4fbc9d008',
      'native_key' => 'maxnotify.statuses',
      'filename' => 'modSystemSetting/29f2390dcf6aaba46a5613cbe162a4a5.vehicle',
      'namespace' => 'maxnotify',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b7f92cf945253961236b4febed7cd30',
      'native_key' => 'maxnotify.form_title',
      'filename' => 'modSystemSetting/133941d30beea00c110f6c220662caec.vehicle',
      'namespace' => 'maxnotify',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5aacfa6f56490574ccb9a4a80d83890f',
      'native_key' => 'maxnotify.formit_title',
      'filename' => 'modSystemSetting/896fe296d48fd0415002cd2a0bc5733b.vehicle',
      'namespace' => 'maxnotify',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88d93d71fb68c4855ace7c42a1be7aea',
      'native_key' => 'maxnotify.sendit_title',
      'filename' => 'modSystemSetting/e452c3115cd22795109de3a9407429e6.vehicle',
      'namespace' => 'maxnotify',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '895e5ef0197c64145752d27cd52ff10d',
      'native_key' => 'maxnotify.form_exclude_fields',
      'filename' => 'modSystemSetting/6902fc9bee0a32633f7a3f29f284d155.vehicle',
      'namespace' => 'maxnotify',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa4bfffbd5336582260ec21993ed87e2',
      'native_key' => 'maxnotify.form_field_labels',
      'filename' => 'modSystemSetting/9f6e25680157a8b9b19f4c57ade396d5.vehicle',
      'namespace' => 'maxnotify',
    ),
  ),
);