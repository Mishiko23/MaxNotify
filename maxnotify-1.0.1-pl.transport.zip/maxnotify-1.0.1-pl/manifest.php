<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'name' => 'MaxNotify',
    'author' => 'Mishiko23',
    'email' => 'bigo2008@gmail.com',
    'description' => 'Уведомления о новых заказах и смене статусов miniShop2 в мессенджер MAX через API rumaxbot.ru.',
    'license' => 'MIT License

Copyright (c) 2026 Mishiko23 <bigo2008@gmail.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# MaxNotify для miniShop2

**MaxNotify** — компонент для MODX Revolution 2, который отправляет сведения
о заказах miniShop2 в мессенджер MAX через сервис
[rumaxbot.ru](https://rumaxbot.ru).

Компонент помогает владельцу и менеджерам интернет-магазина быстро узнавать
о новых заказах и изменениях их статуса без постоянной проверки панели MODX.

## Автор

- Разработчик: **Mishiko23**
- Email: **bigo2008@gmail.com**

## Возможности

- уведомление сразу после создания заказа miniShop2;
- уведомление при изменении статуса заказа;
- фильтрация уведомлений по ID статусов;
- номер, сумма и состав заказа;
- имя, телефон и email покупателя;
- адрес доставки и комментарий клиента;
- название способа доставки и оплаты;
- ссылка на конкретный заказ в панели MODX;
- сообщения в формате Markdown или HTML;
- редактируемые чанки сообщений;
- запись ошибок API и соединения в журнал MODX.

## Требования

- MODX Revolution 2.8+;
- miniShop2 2.x или 4.x;
- PHP 7.2+;
- PHP cURL или включённый `allow_url_fopen`;
- канал и API-ключ сервиса rumaxbot.ru.

Компонент проверен с MODX Revolution 2.8.8-pl и miniShop2 4.4.2-pl.

## Установка

1. Откройте в MODX раздел **Пакеты → Установщик**.
2. Найдите компонент **MaxNotify** в репозитории
   [modstore.pro](https://modstore.pro).
3. Нажмите **Скачать**, затем **Установить**.
4. После установки очистите кэш MODX.

## Настройка

Откройте **Системные настройки** и выберите пространство имён `maxnotify`.

Основные параметры:

- `maxnotify.enabled` — включает или отключает компонент;
- `maxnotify.api_key` — API-ключ канала rumaxbot.ru;
- `maxnotify.api_url` — адрес API отправки сообщений;
- `maxnotify.notify_new_order` — уведомления о новых заказах;
- `maxnotify.notify_status_change` — уведомления о смене статуса;
- `maxnotify.statuses` — ID статусов через запятую, пустое поле разрешает все;
- `maxnotify.format` — формат `markdown` или `html`;
- `maxnotify.timeout` — таймаут API-запроса в секундах.

## Подключение rumaxbot.ru

1. Зарегистрируйтесь на rumaxbot.ru и подтвердите email.
2. Создайте канал.
3. Подключите MAX-бота к каналу по инструкции сервиса.
4. Создайте API-ключ канала.
5. Укажите ключ в настройке `maxnotify.api_key`.

API-ключ нельзя публиковать или добавлять в репозиторий.

## Шаблоны сообщений

После установки в категории элементов `MaxNotify` будут созданы чанки:

- `maxNotifyOrderCreated` — новый заказ в Markdown;
- `maxNotifyOrderStatus` — новый статус в Markdown;
- `maxNotifyOrderCreatedHtml` — новый заказ в HTML;
- `maxNotifyOrderStatusHtml` — новый статус в HTML.

Доступные плейсхолдеры: `num`, `cost`, `receiver`, `phone`, `email`,
`address`, `comment`, `order_comment`, `products`, `delivery_name`,
`payment_name`, `status_name`, `manager_url` и другие поля заказа.
',
    'changelog' => '# История изменений MaxNotify

## 1.0.1-pl

- добавлены данные доставки, оплаты и полный адрес заказа;
- ссылка в сообщении ведёт непосредственно на заказ в MODX.

## 1.0.0-pl

- первая версия компонента;
- уведомления о новых заказах miniShop2;
- уведомления об изменении статусов;
- интеграция с API rumaxbot.ru;
- шаблоны Markdown и HTML.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd833b180a4874fac6f4894edfe3c8a8f',
      'native_key' => 'maxnotify',
      'filename' => 'modNamespace/147d8bab60019ed1907b2999c963be8e.vehicle',
      'namespace' => 'maxnotify',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5a2efea2d004c8e75dd82ad303ced9e3',
      'native_key' => NULL,
      'filename' => 'modCategory/7f6e3bd908febad6e6d794fb30e144c1.vehicle',
      'namespace' => 'maxnotify',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbb05795957c907802a1ea752585542d',
      'native_key' => 'maxnotify.enabled',
      'filename' => 'modSystemSetting/1d7ef0b22430baef301e9bd21c19e427.vehicle',
      'namespace' => 'maxnotify',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7795b2b5b000fba54caba1a29db21af2',
      'native_key' => 'maxnotify.api_url',
      'filename' => 'modSystemSetting/7215e0baf7fbeaf108e0f9e41424f437.vehicle',
      'namespace' => 'maxnotify',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a07f026de4a123b604d658929cacec1',
      'native_key' => 'maxnotify.api_key',
      'filename' => 'modSystemSetting/7fd2ce7530cd7e42c239ba696492b873.vehicle',
      'namespace' => 'maxnotify',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68f139d8a65845a902d39ecbf0da6d34',
      'native_key' => 'maxnotify.format',
      'filename' => 'modSystemSetting/1957dd78f03ee9f2d478803fc7a5dba4.vehicle',
      'namespace' => 'maxnotify',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6d7c7b651536789324081e6fc1e2f0b',
      'native_key' => 'maxnotify.timeout',
      'filename' => 'modSystemSetting/3bfcc73357145b2272d385ddf6c9b733.vehicle',
      'namespace' => 'maxnotify',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92b7ed83006a9b7dd46e313f4e6a2f0f',
      'native_key' => 'maxnotify.notify_new_order',
      'filename' => 'modSystemSetting/697ae0ef016ff6946781fa25090a13c6.vehicle',
      'namespace' => 'maxnotify',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df8191af0732ae5d0de88b3e2e9cae7d',
      'native_key' => 'maxnotify.notify_status_change',
      'filename' => 'modSystemSetting/3d4957e59ac03bace28027adc2d656f7.vehicle',
      'namespace' => 'maxnotify',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf6848c67a0795c85eb5e10704b3b031',
      'native_key' => 'maxnotify.statuses',
      'filename' => 'modSystemSetting/ec24ec68bb3df822af5540b695f8c58a.vehicle',
      'namespace' => 'maxnotify',
    ),
  ),
);