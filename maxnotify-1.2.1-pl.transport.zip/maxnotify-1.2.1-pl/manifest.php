<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'name' => 'MaxNotify',
    'author' => 'Mishiko23',
    'email' => 'bigo2008@gmail.com',
    'description' => 'Уведомления о заказах miniShop2 в MAX через официальный MAX Business API или сервис rumaxbot.ru.',
    'license' => 'MIT License

Copyright (c) 2026 Mishiko23 <bigo2008@gmail.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# MaxNotify для miniShop2

![MaxNotify — уведомления miniShop2 в MAX](docs/maxnotify-cover.png)

**MaxNotify** — компонент для MODX Revolution 2, который отправляет сведения
о заказах miniShop2 в мессенджер MAX через официальный
[MAX Business API](https://dev.max.ru/docs/maxbusiness/connection) или сервис
[rumaxbot.ru](https://rumaxbot.ru).

Компонент помогает владельцу и менеджерам интернет-магазина быстро узнавать
о новых заказах и изменениях их статуса без постоянной проверки панели MODX.

## Автор

- Разработчик: **Mishiko23**
- Email: **bigo2008@gmail.com**

## Возможности

- уведомление сразу после создания заказа miniShop2;
- уведомление при изменении статуса заказа;
- уведомления о заявках FormIt;
- уведомления о заявках SendIt;
- отдельное отключение источников miniShop2, FormIt и SendIt;
- фильтрация уведомлений по ID статусов;
- номер, сумма и состав заказа;
- имя, телефон и email покупателя;
- адрес доставки и комментарий клиента;
- название способа доставки и оплаты;
- ссылка на конкретный заказ в панели MODX;
- официальный MAX Business API и сервис rumaxbot.ru на выбор;
- отправка одному или нескольким чатам, каналам или пользователям;
- сообщения в формате Markdown или HTML;
- редактируемые чанки сообщений;
- запись ошибок API и соединения в журнал MODX.

## Требования

- MODX Revolution 2.8+;
- miniShop2 2.x или 4.x;
- PHP 7.2+;
- PHP cURL или включённый `allow_url_fopen`;
- токен официального MAX-бота или канал и API-ключ rumaxbot.ru.

Компонент проверен с MODX Revolution 2.8.8-pl и miniShop2 4.4.2-pl.

## Установка

1. Откройте в MODX раздел **Пакеты → Установщик**.
2. Найдите компонент **MaxNotify** в репозитории
   [modstore.pro](https://modstore.pro).
3. Нажмите **Скачать**, затем **Установить**.
4. После установки очистите кэш MODX.

## Настройка

Откройте **Системные настройки** и выберите пространство имён `maxnotify`.

Основные параметры:

- `maxnotify.enabled` — включает или отключает компонент;
- `maxnotify.enable_minishop2` — уведомления miniShop2;
- `maxnotify.enable_formit` — уведомления FormIt;
- `maxnotify.enable_sendit` — уведомления SendIt;
- `maxnotify.provider` — `rumaxbot` или `maxbusiness`;
- `maxnotify.format` — формат `markdown` или `html`;
- `maxnotify.timeout` — таймаут API-запроса в секундах;
- `maxnotify.notify_new_order` — уведомления о новых заказах;
- `maxnotify.notify_status_change` — уведомления о смене статуса;
- `maxnotify.statuses` — ID статусов через запятую, пустое поле разрешает все;
- `maxnotify.form_exclude_fields` — технические поля форм, которые не нужно отправлять;
- `maxnotify.form_field_labels` — русские названия полей форм в формате `field=Название`.

## Подключение FormIt

Добавьте hook-сниппет `maxNotifyFormIt` в параметр `&hooks` после успешных
проверок формы.

Пример:

```html
[[!FormIt?
    &hooks=`spam,email,maxNotifyFormIt,redirect`
    &emailTpl=`tpl.Email`
    &redirectTo=`12`
]]
```

Отключить отправку заявок FormIt можно настройкой `maxnotify.enable_formit`.
Заголовок сообщения меняется настройкой `maxnotify.formit_title`.

## Подключение SendIt

Добавьте hook-сниппет `maxNotifySendIt` в цепочку успешной обработки SendIt,
если в вашей конфигурации SendIt используются hook-сниппеты. Сниппет также
умеет брать данные из `$_POST`, поэтому его можно вызывать после успешной
валидации формы.

Отключить отправку заявок SendIt можно настройкой `maxnotify.enable_sendit`.
Заголовок сообщения меняется настройкой `maxnotify.sendit_title`.

## Названия полей форм

По умолчанию MaxNotify показывает частые поля по-русски:

- `name` → `Имя`;
- `phone` → `Телефон`;
- `email` → `Email`;
- `message` → `Сообщение`;
- `comment` → `Комментарий`.

Свои названия можно задать в настройке `maxnotify.form_field_labels`, например:

```text
name=Имя,phone=Телефон,email=Email,service=Услуга
```

Служебные поля вроде `agree`, `pageId`, `nospam` и `nospam:blank`
исключаются настройкой `maxnotify.form_exclude_fields`.

## Подключение официального MAX Business API

Официальное подключение доступно верифицированным организациям и ИП,
которые являются резидентами РФ.

1. Создайте и верифицируйте профиль на
   [платформе MAX для партнёров](https://business.max.ru).
2. Создайте чат-бота и дождитесь прохождения модерации.
3. Получите токен в разделе **Чат-боты → Перейти → Расширенные настройки →
   Настроить**.
4. Добавьте бота в нужный чат или канал либо запустите личный диалог с ботом.
5. Получите `chat_id` или `user_id` через Webhook/Long Polling API MAX.
6. Установите `maxnotify.provider` в значение `maxbusiness`.
7. Заполните настройки:
   - `maxnotify.max_token` — токен бота;
   - `maxnotify.max_ca_cert_path` — необязательный путь к PEM-файлу/CA bundle
     с сертификатом Минцифры;
   - `maxnotify.max_recipient_type` — `chat_id` или `user_id`;
   - `maxnotify.max_recipient_ids` — один или несколько ID через запятую;
   - `maxnotify.max_notify` — уведомлять участников чата;
   - `maxnotify.max_disable_link_preview` — отключить превью ссылок.

Официальный API принимает сообщения длиной до 4000 символов. Более длинные
уведомления MaxNotify автоматически сокращает.

С 19 июля 2026 MAX требует отправлять запросы на домен
`platform-api2.max.ru` вместо `platform-api.max.ru` и добавить сертификат
Минцифры в список доверенных. В MaxNotify новый домен используется по
умолчанию. Если на сервере PHP/cURL не доверяет сертификату системно,
укажите путь к PEM-файлу или CA bundle в настройке
`maxnotify.max_ca_cert_path`.

## Подключение rumaxbot.ru

Установите `maxnotify.provider` в значение `rumaxbot`, затем укажите:

- `maxnotify.api_key` — API-ключ канала rumaxbot.ru;
- `maxnotify.api_url` — адрес API отправки сообщений;

1. Зарегистрируйтесь на rumaxbot.ru и подтвердите email.
2. Создайте канал.
3. Подключите MAX-бота к каналу по инструкции сервиса.
4. Создайте API-ключ канала.
5. Укажите ключ в настройке `maxnotify.api_key`.

API-ключ нельзя публиковать или добавлять в репозиторий.

## Шаблоны сообщений

После установки в категории элементов `MaxNotify` будут созданы чанки:

- `maxNotifyOrderCreated` — новый заказ в Markdown;
- `maxNotifyOrderStatus` — новый статус в Markdown;
- `maxNotifyOrderCreatedHtml` — новый заказ в HTML;
- `maxNotifyOrderStatusHtml` — новый статус в HTML;
- `maxNotifyForm` — заявка с формы в Markdown;
- `maxNotifyFormHtml` — заявка с формы в HTML.

Доступные плейсхолдеры: `num`, `cost`, `receiver`, `phone`, `email`,
`address`, `comment`, `order_comment`, `products`, `delivery_name`,
`payment_name`, `status_name`, `manager_url`, `source`, `title`, `fields`,
`resource_id`, `resource_pagetitle`, `ip` и другие поля заказа или формы.
',
    'changelog' => '# История изменений MaxNotify

## 1.2.1-pl

- добавлены русские названия полей форм по умолчанию;
- добавлена настройка `maxnotify.form_field_labels` для переименования полей форм;
- расширен список технических полей, исключаемых из уведомлений;
- исправлена фильтрация составных полей вроде `nospam:blank`.

## 1.2.0-pl

- добавлены уведомления о заявках FormIt через hook-сниппет `maxNotifyFormIt`;
- добавлены уведомления о заявках SendIt через hook-сниппет `maxNotifySendIt`;
- добавлен общий шаблон заявки `maxNotifyForm` и HTML-версия `maxNotifyFormHtml`;
- добавлены отдельные переключатели источников `maxnotify.enable_minishop2`, `maxnotify.enable_formit`, `maxnotify.enable_sendit`;
- добавлен список исключаемых технических полей формы `maxnotify.form_exclude_fields`;
- добавлены отдельные заголовки уведомлений FormIt и SendIt.

## 1.1.1-pl

- обновлён официальный endpoint MAX Business API на `https://platform-api2.max.ru/messages`;
- добавлена миграция старого значения `platform-api.max.ru` при обновлении пакета;
- добавлена настройка `maxnotify.max_ca_cert_path` для PEM-файла/CA bundle с сертификатом Минцифры;
- обновлена документация по требованию MAX перейти на новый домен до 19 июля 2026.

## 1.1.0-pl

- добавлена прямая интеграция с официальным MAX Business API;
- добавлен выбор провайдера между MAX Business и rumaxbot.ru;
- добавлена отправка в чат, канал или пользователю по `chat_id`/`user_id`;
- добавлена отправка нескольким получателям;
- учтено ограничение официального API в 4000 символов;
- сохранена обратная совместимость с настройками rumaxbot.ru.

## 1.0.1-pl

- добавлены данные доставки, оплаты и полный адрес заказа;
- ссылка в сообщении ведёт непосредственно на заказ в MODX.

## 1.0.0-pl

- первая версия компонента;
- уведомления о новых заказах miniShop2;
- уведомления об изменении статусов;
- интеграция с API rumaxbot.ru;
- шаблоны Markdown и HTML.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3a7d560c9e393b9ec2fb7e0744409e3e',
      'native_key' => 'maxnotify',
      'filename' => 'modNamespace/6402a9de8b04bb7990b4cf413879a3aa.vehicle',
      'namespace' => 'maxnotify',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '51eacc2bf90c953f896ff8c3a21299c3',
      'native_key' => NULL,
      'filename' => 'modCategory/ecf7abfcd1b97aaff61fa0e187454dbd.vehicle',
      'namespace' => 'maxnotify',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf992a802d4f35592af68d23856d24a5',
      'native_key' => 'maxnotify.enabled',
      'filename' => 'modSystemSetting/babf6fae7fbbeb608acaa924b0ad0a8b.vehicle',
      'namespace' => 'maxnotify',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4fb5b08d02d1158a32abd8cc6546ecc',
      'native_key' => 'maxnotify.enable_minishop2',
      'filename' => 'modSystemSetting/c9ea5b693cb564c0f5a2560e8327c723.vehicle',
      'namespace' => 'maxnotify',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a361263967004e5b5e1f02dbf197f06b',
      'native_key' => 'maxnotify.enable_formit',
      'filename' => 'modSystemSetting/0a22d0b2cf263eb473dbe8c8a8721fca.vehicle',
      'namespace' => 'maxnotify',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e91622c3812d2106634081516dab88f',
      'native_key' => 'maxnotify.enable_sendit',
      'filename' => 'modSystemSetting/b3df0320e375fe1ad92f8e8935e146c8.vehicle',
      'namespace' => 'maxnotify',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f87a933aa04b0c80136619bfe368e606',
      'native_key' => 'maxnotify.provider',
      'filename' => 'modSystemSetting/0930041883c91a6fc00d4c7053a17b99.vehicle',
      'namespace' => 'maxnotify',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f950267a35eb1809e6beb6a22d33d68e',
      'native_key' => 'maxnotify.api_url',
      'filename' => 'modSystemSetting/7e632dda99c80042eb5951571c765458.vehicle',
      'namespace' => 'maxnotify',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f580c67b69dde8ebd91c86b5810d0616',
      'native_key' => 'maxnotify.api_key',
      'filename' => 'modSystemSetting/971282e87c9b3e25897f96f5e693f022.vehicle',
      'namespace' => 'maxnotify',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6dc6bb0715dd665fa3e4d2213879eada',
      'native_key' => 'maxnotify.max_api_url',
      'filename' => 'modSystemSetting/d63c1b909ae30358e7d0c681c039be70.vehicle',
      'namespace' => 'maxnotify',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64d6eab7d3f25c98d99475db3b12ed49',
      'native_key' => 'maxnotify.max_token',
      'filename' => 'modSystemSetting/dd9bc7d6f9dad2c47359a2078e1f9c63.vehicle',
      'namespace' => 'maxnotify',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c20bd75056f5fdfad1c104225e4d6537',
      'native_key' => 'maxnotify.max_ca_cert_path',
      'filename' => 'modSystemSetting/2f355b1646fd6ae729ddff5e9a582f54.vehicle',
      'namespace' => 'maxnotify',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22424f7ab6a82fc617acb9cab959aaea',
      'native_key' => 'maxnotify.max_recipient_type',
      'filename' => 'modSystemSetting/06a84a8fa9967dc6986eb11fa335d74d.vehicle',
      'namespace' => 'maxnotify',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ada2131dfd688c1dc2aa2b9ef11d2ba6',
      'native_key' => 'maxnotify.max_recipient_ids',
      'filename' => 'modSystemSetting/4773232cca26d1f47afa3798587367d1.vehicle',
      'namespace' => 'maxnotify',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56390ec8690f2563b693d7ed82b808f1',
      'native_key' => 'maxnotify.max_notify',
      'filename' => 'modSystemSetting/62ef26b4f8b8ccf29b00fa07071e0ab3.vehicle',
      'namespace' => 'maxnotify',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac3f282e0a44bd058d94bbf3a224ca3e',
      'native_key' => 'maxnotify.max_disable_link_preview',
      'filename' => 'modSystemSetting/9592aa61a603a0487e72748e50893768.vehicle',
      'namespace' => 'maxnotify',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75d2c4a993bbedd27b939cd2f1769d86',
      'native_key' => 'maxnotify.format',
      'filename' => 'modSystemSetting/ab00c46138a4ad5185fbe3de2f85ff4e.vehicle',
      'namespace' => 'maxnotify',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc333decbcae8e9b0b2544c71903a839',
      'native_key' => 'maxnotify.timeout',
      'filename' => 'modSystemSetting/2b45fe66fde8636e2df7f9016b3b2177.vehicle',
      'namespace' => 'maxnotify',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c765b73e5453cc8dd28149bc8e7221d1',
      'native_key' => 'maxnotify.notify_new_order',
      'filename' => 'modSystemSetting/1d17f743f5bfb51a74ebde2d8f4df354.vehicle',
      'namespace' => 'maxnotify',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c3701a6b56cb0799f914a036ac40e5f',
      'native_key' => 'maxnotify.notify_status_change',
      'filename' => 'modSystemSetting/3240924e6b6a1fd890cbd760142abb4c.vehicle',
      'namespace' => 'maxnotify',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9189a3220d4095555b060d97fe1fe6e9',
      'native_key' => 'maxnotify.statuses',
      'filename' => 'modSystemSetting/3e15819cc4304f44b48f3cd38fa2eb41.vehicle',
      'namespace' => 'maxnotify',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8640e74ac83e557ba2e3ca8a479f2647',
      'native_key' => 'maxnotify.form_title',
      'filename' => 'modSystemSetting/7b8ba7548fe00b28eb1f9f0152086a38.vehicle',
      'namespace' => 'maxnotify',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf78c7542fb5eff8ad8aaaf24c17ecf7',
      'native_key' => 'maxnotify.formit_title',
      'filename' => 'modSystemSetting/d87c65695656f255cdba6c30f9252bc0.vehicle',
      'namespace' => 'maxnotify',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '564fe3ebd126b89262ea0f97c505c7c9',
      'native_key' => 'maxnotify.sendit_title',
      'filename' => 'modSystemSetting/8021ddfbb94520f7f21655d9c8ce6c0e.vehicle',
      'namespace' => 'maxnotify',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '618e404db85f6c36103e8ab085f83371',
      'native_key' => 'maxnotify.form_exclude_fields',
      'filename' => 'modSystemSetting/76aa95003a7420e0c2cdb5053a620445.vehicle',
      'namespace' => 'maxnotify',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a8c9723fd1315efd7b05b9c5f581116',
      'native_key' => 'maxnotify.form_field_labels',
      'filename' => 'modSystemSetting/3f149c52132ccbf5b242b8fa80fdd167.vehicle',
      'namespace' => 'maxnotify',
    ),
  ),
);