<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'name' => 'MaxNotify',
    'author' => 'Mishiko23',
    'email' => 'bigo2008@gmail.com',
    'description' => 'Уведомления о заказах miniShop2 в MAX через официальный MAX Business API или сервис rumaxbot.ru.',
    'license' => 'MIT License

Copyright (c) 2026 Mishiko23 <bigo2008@gmail.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# MaxNotify для miniShop2

![MaxNotify — уведомления miniShop2 в MAX](docs/maxnotify-cover.png)

**MaxNotify** — компонент для MODX Revolution 2, который отправляет сведения
о заказах miniShop2 в мессенджер MAX через официальный
[MAX Business API](https://dev.max.ru/docs/maxbusiness/connection) или сервис
[rumaxbot.ru](https://rumaxbot.ru).

Компонент помогает владельцу и менеджерам интернет-магазина быстро узнавать
о новых заказах и изменениях их статуса без постоянной проверки панели MODX.

## Автор

- Разработчик: **Mishiko23**
- Email: **bigo2008@gmail.com**

## Возможности

- уведомление сразу после создания заказа miniShop2;
- уведомление при изменении статуса заказа;
- фильтрация уведомлений по ID статусов;
- номер, сумма и состав заказа;
- имя, телефон и email покупателя;
- адрес доставки и комментарий клиента;
- название способа доставки и оплаты;
- ссылка на конкретный заказ в панели MODX;
- официальный MAX Business API и сервис rumaxbot.ru на выбор;
- отправка одному или нескольким чатам, каналам или пользователям;
- сообщения в формате Markdown или HTML;
- редактируемые чанки сообщений;
- запись ошибок API и соединения в журнал MODX.

## Требования

- MODX Revolution 2.8+;
- miniShop2 2.x или 4.x;
- PHP 7.2+;
- PHP cURL или включённый `allow_url_fopen`;
- токен официального MAX-бота или канал и API-ключ rumaxbot.ru.

Компонент проверен с MODX Revolution 2.8.8-pl и miniShop2 4.4.2-pl.

## Установка

1. Откройте в MODX раздел **Пакеты → Установщик**.
2. Найдите компонент **MaxNotify** в репозитории
   [modstore.pro](https://modstore.pro).
3. Нажмите **Скачать**, затем **Установить**.
4. После установки очистите кэш MODX.

## Настройка

Откройте **Системные настройки** и выберите пространство имён `maxnotify`.

Основные параметры:

- `maxnotify.enabled` — включает или отключает компонент;
- `maxnotify.provider` — `rumaxbot` или `maxbusiness`;
- `maxnotify.format` — формат `markdown` или `html`;
- `maxnotify.timeout` — таймаут API-запроса в секундах;
- `maxnotify.notify_new_order` — уведомления о новых заказах;
- `maxnotify.notify_status_change` — уведомления о смене статуса;
- `maxnotify.statuses` — ID статусов через запятую, пустое поле разрешает все.

## Подключение официального MAX Business API

Официальное подключение доступно верифицированным организациям и ИП,
которые являются резидентами РФ.

1. Создайте и верифицируйте профиль на
   [платформе MAX для партнёров](https://business.max.ru).
2. Создайте чат-бота и дождитесь прохождения модерации.
3. Получите токен в разделе **Чат-боты → Перейти → Расширенные настройки →
   Настроить**.
4. Добавьте бота в нужный чат или канал либо запустите личный диалог с ботом.
5. Получите `chat_id` или `user_id` через Webhook/Long Polling API MAX.
6. Установите `maxnotify.provider` в значение `maxbusiness`.
7. Заполните настройки:
   - `maxnotify.max_token` — токен бота;
   - `maxnotify.max_recipient_type` — `chat_id` или `user_id`;
   - `maxnotify.max_recipient_ids` — один или несколько ID через запятую;
   - `maxnotify.max_notify` — уведомлять участников чата;
   - `maxnotify.max_disable_link_preview` — отключить превью ссылок.

Официальный API принимает сообщения длиной до 4000 символов. Более длинные
уведомления MaxNotify автоматически сокращает.

## Подключение rumaxbot.ru

Установите `maxnotify.provider` в значение `rumaxbot`, затем укажите:

- `maxnotify.api_key` — API-ключ канала rumaxbot.ru;
- `maxnotify.api_url` — адрес API отправки сообщений;

1. Зарегистрируйтесь на rumaxbot.ru и подтвердите email.
2. Создайте канал.
3. Подключите MAX-бота к каналу по инструкции сервиса.
4. Создайте API-ключ канала.
5. Укажите ключ в настройке `maxnotify.api_key`.

API-ключ нельзя публиковать или добавлять в репозиторий.

## Шаблоны сообщений

После установки в категории элементов `MaxNotify` будут созданы чанки:

- `maxNotifyOrderCreated` — новый заказ в Markdown;
- `maxNotifyOrderStatus` — новый статус в Markdown;
- `maxNotifyOrderCreatedHtml` — новый заказ в HTML;
- `maxNotifyOrderStatusHtml` — новый статус в HTML.

Доступные плейсхолдеры: `num`, `cost`, `receiver`, `phone`, `email`,
`address`, `comment`, `order_comment`, `products`, `delivery_name`,
`payment_name`, `status_name`, `manager_url` и другие поля заказа.
',
    'changelog' => '# История изменений MaxNotify

## 1.1.0-pl

- добавлена прямая интеграция с официальным MAX Business API;
- добавлен выбор провайдера между MAX Business и rumaxbot.ru;
- добавлена отправка в чат, канал или пользователю по `chat_id`/`user_id`;
- добавлена отправка нескольким получателям;
- учтено ограничение официального API в 4000 символов;
- сохранена обратная совместимость с настройками rumaxbot.ru.

## 1.0.1-pl

- добавлены данные доставки, оплаты и полный адрес заказа;
- ссылка в сообщении ведёт непосредственно на заказ в MODX.

## 1.0.0-pl

- первая версия компонента;
- уведомления о новых заказах miniShop2;
- уведомления об изменении статусов;
- интеграция с API rumaxbot.ru;
- шаблоны Markdown и HTML.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'fa2928cf9eda72b4cef71215b0673c34',
      'native_key' => 'maxnotify',
      'filename' => 'modNamespace/6a146b14ad06feab811e25f8760111d2.vehicle',
      'namespace' => 'maxnotify',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'cad537e4726f6fc5513828db7cf5b308',
      'native_key' => NULL,
      'filename' => 'modCategory/3d6d42425704fefa772295e9b7ca594d.vehicle',
      'namespace' => 'maxnotify',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7609685c554a06f9916a0a1325516d0c',
      'native_key' => 'maxnotify.enabled',
      'filename' => 'modSystemSetting/66ea28e78a572f7e99a03f32aa3b6be7.vehicle',
      'namespace' => 'maxnotify',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '483b96fec9ca778363e40409f7c8cfdb',
      'native_key' => 'maxnotify.provider',
      'filename' => 'modSystemSetting/31a5efe44b80ce6302428edfa5d35dbc.vehicle',
      'namespace' => 'maxnotify',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df6f4c654a8a4eec43ca16728391e087',
      'native_key' => 'maxnotify.api_url',
      'filename' => 'modSystemSetting/4d21b5274d1e4c8174e55ad3f8c33b35.vehicle',
      'namespace' => 'maxnotify',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84a9d2d46aa5e8c2c5ea6c2fa8fa3a74',
      'native_key' => 'maxnotify.api_key',
      'filename' => 'modSystemSetting/978ccf2e83b384bd11dbc8b7766dbd32.vehicle',
      'namespace' => 'maxnotify',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '216f09f583b357300b3879af7eb191ed',
      'native_key' => 'maxnotify.max_api_url',
      'filename' => 'modSystemSetting/2472fc88c7f44f03f5ba5aafdb9a53e8.vehicle',
      'namespace' => 'maxnotify',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25f600f61176189beeea5d8cb68a7db1',
      'native_key' => 'maxnotify.max_token',
      'filename' => 'modSystemSetting/04c0434b182020d6099ce14be0f595e6.vehicle',
      'namespace' => 'maxnotify',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e644199798472ab974eef50ceff07e1f',
      'native_key' => 'maxnotify.max_recipient_type',
      'filename' => 'modSystemSetting/7a41c676d6847c48c1b0175a45ae0d29.vehicle',
      'namespace' => 'maxnotify',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '969219ab33eac16d5ca72a9b29679ee7',
      'native_key' => 'maxnotify.max_recipient_ids',
      'filename' => 'modSystemSetting/71b9010da8dbcee24b30535238f1560c.vehicle',
      'namespace' => 'maxnotify',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78f839f00bf107a11297e716c3040465',
      'native_key' => 'maxnotify.max_notify',
      'filename' => 'modSystemSetting/8492d1b4802be365e2b4e4dc41a9fc9a.vehicle',
      'namespace' => 'maxnotify',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9a9687eebf158b34884135b6e384401',
      'native_key' => 'maxnotify.max_disable_link_preview',
      'filename' => 'modSystemSetting/fefbaceba4d1312889cf3c4113bb1fd1.vehicle',
      'namespace' => 'maxnotify',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33bbc1aa825ccc3aa826f554708c8cd5',
      'native_key' => 'maxnotify.format',
      'filename' => 'modSystemSetting/5aad8c73591f008e261b9803dde39d86.vehicle',
      'namespace' => 'maxnotify',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'edd3adde4422bca60658ae830d112721',
      'native_key' => 'maxnotify.timeout',
      'filename' => 'modSystemSetting/d2a17980c3112f8f2b3a148a1aa43f28.vehicle',
      'namespace' => 'maxnotify',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee9e7e2a43f4e59bc09637b6c6c6dcef',
      'native_key' => 'maxnotify.notify_new_order',
      'filename' => 'modSystemSetting/637f637b472aac1b8a5a87361636a03f.vehicle',
      'namespace' => 'maxnotify',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7cd3ef68ff683863b450c3bd67e152a6',
      'native_key' => 'maxnotify.notify_status_change',
      'filename' => 'modSystemSetting/a8aeed6a4ac10b6631e405bcb591ff89.vehicle',
      'namespace' => 'maxnotify',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a051739c9dfcbcb76002b610742671c',
      'native_key' => 'maxnotify.statuses',
      'filename' => 'modSystemSetting/bf0f3b13d74a050f93d7e94e75c3e32b.vehicle',
      'namespace' => 'maxnotify',
    ),
  ),
);