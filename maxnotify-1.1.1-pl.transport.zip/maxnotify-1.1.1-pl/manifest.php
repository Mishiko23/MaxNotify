<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'name' => 'MaxNotify',
    'author' => 'Mishiko23',
    'email' => 'bigo2008@gmail.com',
    'description' => 'Уведомления о заказах miniShop2 в MAX через официальный MAX Business API или сервис rumaxbot.ru.',
    'license' => 'MIT License

Copyright (c) 2026 Mishiko23 <bigo2008@gmail.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# MaxNotify для miniShop2

![MaxNotify — уведомления miniShop2 в MAX](docs/maxnotify-cover.png)

**MaxNotify** — компонент для MODX Revolution 2, который отправляет сведения
о заказах miniShop2 в мессенджер MAX через официальный
[MAX Business API](https://dev.max.ru/docs/maxbusiness/connection) или сервис
[rumaxbot.ru](https://rumaxbot.ru).

Компонент помогает владельцу и менеджерам интернет-магазина быстро узнавать
о новых заказах и изменениях их статуса без постоянной проверки панели MODX.

## Автор

- Разработчик: **Mishiko23**
- Email: **bigo2008@gmail.com**

## Возможности

- уведомление сразу после создания заказа miniShop2;
- уведомление при изменении статуса заказа;
- фильтрация уведомлений по ID статусов;
- номер, сумма и состав заказа;
- имя, телефон и email покупателя;
- адрес доставки и комментарий клиента;
- название способа доставки и оплаты;
- ссылка на конкретный заказ в панели MODX;
- официальный MAX Business API и сервис rumaxbot.ru на выбор;
- отправка одному или нескольким чатам, каналам или пользователям;
- сообщения в формате Markdown или HTML;
- редактируемые чанки сообщений;
- запись ошибок API и соединения в журнал MODX.

## Требования

- MODX Revolution 2.8+;
- miniShop2 2.x или 4.x;
- PHP 7.2+;
- PHP cURL или включённый `allow_url_fopen`;
- токен официального MAX-бота или канал и API-ключ rumaxbot.ru.

Компонент проверен с MODX Revolution 2.8.8-pl и miniShop2 4.4.2-pl.

## Установка

1. Откройте в MODX раздел **Пакеты → Установщик**.
2. Найдите компонент **MaxNotify** в репозитории
   [modstore.pro](https://modstore.pro).
3. Нажмите **Скачать**, затем **Установить**.
4. После установки очистите кэш MODX.

## Настройка

Откройте **Системные настройки** и выберите пространство имён `maxnotify`.

Основные параметры:

- `maxnotify.enabled` — включает или отключает компонент;
- `maxnotify.provider` — `rumaxbot` или `maxbusiness`;
- `maxnotify.format` — формат `markdown` или `html`;
- `maxnotify.timeout` — таймаут API-запроса в секундах;
- `maxnotify.notify_new_order` — уведомления о новых заказах;
- `maxnotify.notify_status_change` — уведомления о смене статуса;
- `maxnotify.statuses` — ID статусов через запятую, пустое поле разрешает все.

## Подключение официального MAX Business API

Официальное подключение доступно верифицированным организациям и ИП,
которые являются резидентами РФ.

1. Создайте и верифицируйте профиль на
   [платформе MAX для партнёров](https://business.max.ru).
2. Создайте чат-бота и дождитесь прохождения модерации.
3. Получите токен в разделе **Чат-боты → Перейти → Расширенные настройки →
   Настроить**.
4. Добавьте бота в нужный чат или канал либо запустите личный диалог с ботом.
5. Получите `chat_id` или `user_id` через Webhook/Long Polling API MAX.
6. Установите `maxnotify.provider` в значение `maxbusiness`.
7. Заполните настройки:
   - `maxnotify.max_token` — токен бота;
   - `maxnotify.max_ca_cert_path` — необязательный путь к PEM-файлу/CA bundle
     с сертификатом Минцифры;
   - `maxnotify.max_recipient_type` — `chat_id` или `user_id`;
   - `maxnotify.max_recipient_ids` — один или несколько ID через запятую;
   - `maxnotify.max_notify` — уведомлять участников чата;
   - `maxnotify.max_disable_link_preview` — отключить превью ссылок.

Официальный API принимает сообщения длиной до 4000 символов. Более длинные
уведомления MaxNotify автоматически сокращает.

С 19 июля 2026 MAX требует отправлять запросы на домен
`platform-api2.max.ru` вместо `platform-api.max.ru` и добавить сертификат
Минцифры в список доверенных. В MaxNotify новый домен используется по
умолчанию. Если на сервере PHP/cURL не доверяет сертификату системно,
укажите путь к PEM-файлу или CA bundle в настройке
`maxnotify.max_ca_cert_path`.

## Подключение rumaxbot.ru

Установите `maxnotify.provider` в значение `rumaxbot`, затем укажите:

- `maxnotify.api_key` — API-ключ канала rumaxbot.ru;
- `maxnotify.api_url` — адрес API отправки сообщений;

1. Зарегистрируйтесь на rumaxbot.ru и подтвердите email.
2. Создайте канал.
3. Подключите MAX-бота к каналу по инструкции сервиса.
4. Создайте API-ключ канала.
5. Укажите ключ в настройке `maxnotify.api_key`.

API-ключ нельзя публиковать или добавлять в репозиторий.

## Шаблоны сообщений

После установки в категории элементов `MaxNotify` будут созданы чанки:

- `maxNotifyOrderCreated` — новый заказ в Markdown;
- `maxNotifyOrderStatus` — новый статус в Markdown;
- `maxNotifyOrderCreatedHtml` — новый заказ в HTML;
- `maxNotifyOrderStatusHtml` — новый статус в HTML.

Доступные плейсхолдеры: `num`, `cost`, `receiver`, `phone`, `email`,
`address`, `comment`, `order_comment`, `products`, `delivery_name`,
`payment_name`, `status_name`, `manager_url` и другие поля заказа.
',
    'changelog' => '# История изменений MaxNotify

## 1.1.1-pl

- обновлён официальный endpoint MAX Business API на `https://platform-api2.max.ru/messages`;
- добавлена миграция старого значения `platform-api.max.ru` при обновлении пакета;
- добавлена настройка `maxnotify.max_ca_cert_path` для PEM-файла/CA bundle с сертификатом Минцифры;
- обновлена документация по требованию MAX перейти на новый домен до 19 июля 2026.

## 1.1.0-pl

- добавлена прямая интеграция с официальным MAX Business API;
- добавлен выбор провайдера между MAX Business и rumaxbot.ru;
- добавлена отправка в чат, канал или пользователю по `chat_id`/`user_id`;
- добавлена отправка нескольким получателям;
- учтено ограничение официального API в 4000 символов;
- сохранена обратная совместимость с настройками rumaxbot.ru.

## 1.0.1-pl

- добавлены данные доставки, оплаты и полный адрес заказа;
- ссылка в сообщении ведёт непосредственно на заказ в MODX.

## 1.0.0-pl

- первая версия компонента;
- уведомления о новых заказах miniShop2;
- уведомления об изменении статусов;
- интеграция с API rumaxbot.ru;
- шаблоны Markdown и HTML.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ab9d99eec8d72903933022406e37a1b4',
      'native_key' => 'maxnotify',
      'filename' => 'modNamespace/51a20e41cd4350750865a522a8c193f6.vehicle',
      'namespace' => 'maxnotify',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5178f2b89dc63460386d29e45dacff31',
      'native_key' => NULL,
      'filename' => 'modCategory/2d9853ff770e02c21329e10adf17136f.vehicle',
      'namespace' => 'maxnotify',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbaac9635d50df67aeb2743d57ca11e0',
      'native_key' => 'maxnotify.enabled',
      'filename' => 'modSystemSetting/56f9aa4f85561d0670805c2f50343cb7.vehicle',
      'namespace' => 'maxnotify',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64b73f1c64f11da6a5d6d5afeb9b45b1',
      'native_key' => 'maxnotify.provider',
      'filename' => 'modSystemSetting/d3072ec5236da4e091830075fd0356d4.vehicle',
      'namespace' => 'maxnotify',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0f91bfe5de5385e432cdd1035bf20d8',
      'native_key' => 'maxnotify.api_url',
      'filename' => 'modSystemSetting/82bdcb245b0d5d959f7a4e2ef7734371.vehicle',
      'namespace' => 'maxnotify',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e13335790245bd6cc495267c6e751fc',
      'native_key' => 'maxnotify.api_key',
      'filename' => 'modSystemSetting/cb5e473e24ce2085cb06e218e94bce8b.vehicle',
      'namespace' => 'maxnotify',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f25d9fb7140ac89ec34ce7c3b375cad0',
      'native_key' => 'maxnotify.max_api_url',
      'filename' => 'modSystemSetting/dcbb1a088881a8edb84450e8d2d20709.vehicle',
      'namespace' => 'maxnotify',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a33a2ebd8bb04c99f74b77b2f3254144',
      'native_key' => 'maxnotify.max_token',
      'filename' => 'modSystemSetting/42063dedef40f177d37661fcdb121265.vehicle',
      'namespace' => 'maxnotify',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ecc66ef0d88ab6116f82f006760f8866',
      'native_key' => 'maxnotify.max_ca_cert_path',
      'filename' => 'modSystemSetting/1f5e26e43f1d77bcab7c2185868424aa.vehicle',
      'namespace' => 'maxnotify',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12c1580af82a4e1a7f3d23366340b438',
      'native_key' => 'maxnotify.max_recipient_type',
      'filename' => 'modSystemSetting/864136d62c08f019786d35f69577a0c7.vehicle',
      'namespace' => 'maxnotify',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc1f2c6c99c73a49f6e81b77da62eea9',
      'native_key' => 'maxnotify.max_recipient_ids',
      'filename' => 'modSystemSetting/fc9822406ad019273e525ee54d8a98c5.vehicle',
      'namespace' => 'maxnotify',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26c77720870a81f18e800df948a84ad2',
      'native_key' => 'maxnotify.max_notify',
      'filename' => 'modSystemSetting/725a3325b29ae003f26fb1af29d28a77.vehicle',
      'namespace' => 'maxnotify',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b61ef995620d7f0e574675eae1d55892',
      'native_key' => 'maxnotify.max_disable_link_preview',
      'filename' => 'modSystemSetting/15633e9548dbfcbacb5042becafbde86.vehicle',
      'namespace' => 'maxnotify',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '175126e3f3c66e467a47433aef2444ae',
      'native_key' => 'maxnotify.format',
      'filename' => 'modSystemSetting/ef85cd34922fd0669c640e98d97add76.vehicle',
      'namespace' => 'maxnotify',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08ecfb19211746fa823d427afc015488',
      'native_key' => 'maxnotify.timeout',
      'filename' => 'modSystemSetting/e6ae5e89bd41328784a01736cb1406d4.vehicle',
      'namespace' => 'maxnotify',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '110d906c8f0d0313ddfc7123d2fe65a0',
      'native_key' => 'maxnotify.notify_new_order',
      'filename' => 'modSystemSetting/24bbecaea8b5479d90e8ab87014aec66.vehicle',
      'namespace' => 'maxnotify',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '455760756fcd6c438b55dcf019f5140a',
      'native_key' => 'maxnotify.notify_status_change',
      'filename' => 'modSystemSetting/58ccc8b6dff6d37f3c5989747b1b29c5.vehicle',
      'namespace' => 'maxnotify',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcd772aa7d044e0fc085ff5a7bbaba40',
      'native_key' => 'maxnotify.statuses',
      'filename' => 'modSystemSetting/5dfd26e50b52c440f5c49da2912c99a1.vehicle',
      'namespace' => 'maxnotify',
    ),
  ),
);