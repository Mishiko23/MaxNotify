<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'name' => 'MaxNotify',
    'author' => 'Mishiko23',
    'email' => 'bigo2008@gmail.com',
    'description' => 'Уведомления о заказах miniShop2 в MAX через официальный MAX Business API или сервис rumaxbot.ru.',
    'license' => 'MIT License

Copyright (c) 2026 Mishiko23 <bigo2008@gmail.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# MaxNotify для miniShop2

![MaxNotify — уведомления miniShop2 в MAX](docs/maxnotify-cover.png)

**MaxNotify** — компонент для MODX Revolution 2, который отправляет сведения
о заказах miniShop2 в мессенджер MAX через официальный
[MAX Business API](https://dev.max.ru/docs/maxbusiness/connection) или сервис
[rumaxbot.ru](https://rumaxbot.ru).

Компонент помогает владельцу и менеджерам интернет-магазина быстро узнавать
о новых заказах и изменениях их статуса без постоянной проверки панели MODX.

## Автор

- Разработчик: **Mishiko23**
- Email: **bigo2008@gmail.com**

## Возможности

- уведомление сразу после создания заказа miniShop2;
- уведомление при изменении статуса заказа;
- уведомления о заявках FormIt;
- уведомления о заявках SendIt;
- отдельное отключение источников miniShop2, FormIt и SendIt;
- фильтрация уведомлений по ID статусов;
- номер, сумма и состав заказа;
- имя, телефон и email покупателя;
- адрес доставки и комментарий клиента;
- название способа доставки и оплаты;
- ссылка на конкретный заказ в панели MODX;
- официальный MAX Business API и сервис rumaxbot.ru на выбор;
- отправка одному или нескольким чатам, каналам или пользователям;
- сообщения в формате Markdown или HTML;
- редактируемые чанки сообщений;
- запись ошибок API и соединения в журнал MODX.

## Требования

- MODX Revolution 2.8+;
- miniShop2 2.x или 4.x;
- PHP 7.2+;
- PHP cURL или включённый `allow_url_fopen`;
- токен официального MAX-бота или канал и API-ключ rumaxbot.ru.

Компонент проверен с MODX Revolution 2.8.8-pl и miniShop2 4.4.2-pl.

## Установка

1. Откройте в MODX раздел **Пакеты → Установщик**.
2. Найдите компонент **MaxNotify** в репозитории
   [modstore.pro](https://modstore.pro).
3. Нажмите **Скачать**, затем **Установить**.
4. После установки очистите кэш MODX.

## Настройка

Откройте **Системные настройки** и выберите пространство имён `maxnotify`.

Основные параметры:

- `maxnotify.enabled` — включает или отключает компонент;
- `maxnotify.enable_minishop2` — уведомления miniShop2;
- `maxnotify.enable_formit` — уведомления FormIt;
- `maxnotify.enable_sendit` — уведомления SendIt;
- `maxnotify.provider` — `rumaxbot` или `maxbusiness`;
- `maxnotify.format` — формат `markdown` или `html`;
- `maxnotify.timeout` — таймаут API-запроса в секундах;
- `maxnotify.notify_new_order` — уведомления о новых заказах;
- `maxnotify.notify_status_change` — уведомления о смене статуса;
- `maxnotify.statuses` — ID статусов через запятую, пустое поле разрешает все;
- `maxnotify.form_exclude_fields` — технические поля форм, которые не нужно отправлять.

## Подключение FormIt

Добавьте hook-сниппет `maxNotifyFormIt` в параметр `&hooks` после успешных
проверок формы.

Пример:

```html
[[!FormIt?
    &hooks=`spam,email,maxNotifyFormIt,redirect`
    &emailTpl=`tpl.Email`
    &redirectTo=`12`
]]
```

Отключить отправку заявок FormIt можно настройкой `maxnotify.enable_formit`.
Заголовок сообщения меняется настройкой `maxnotify.formit_title`.

## Подключение SendIt

Добавьте hook-сниппет `maxNotifySendIt` в цепочку успешной обработки SendIt,
если в вашей конфигурации SendIt используются hook-сниппеты. Сниппет также
умеет брать данные из `$_POST`, поэтому его можно вызывать после успешной
валидации формы.

Отключить отправку заявок SendIt можно настройкой `maxnotify.enable_sendit`.
Заголовок сообщения меняется настройкой `maxnotify.sendit_title`.

## Подключение официального MAX Business API

Официальное подключение доступно верифицированным организациям и ИП,
которые являются резидентами РФ.

1. Создайте и верифицируйте профиль на
   [платформе MAX для партнёров](https://business.max.ru).
2. Создайте чат-бота и дождитесь прохождения модерации.
3. Получите токен в разделе **Чат-боты → Перейти → Расширенные настройки →
   Настроить**.
4. Добавьте бота в нужный чат или канал либо запустите личный диалог с ботом.
5. Получите `chat_id` или `user_id` через Webhook/Long Polling API MAX.
6. Установите `maxnotify.provider` в значение `maxbusiness`.
7. Заполните настройки:
   - `maxnotify.max_token` — токен бота;
   - `maxnotify.max_ca_cert_path` — необязательный путь к PEM-файлу/CA bundle
     с сертификатом Минцифры;
   - `maxnotify.max_recipient_type` — `chat_id` или `user_id`;
   - `maxnotify.max_recipient_ids` — один или несколько ID через запятую;
   - `maxnotify.max_notify` — уведомлять участников чата;
   - `maxnotify.max_disable_link_preview` — отключить превью ссылок.

Официальный API принимает сообщения длиной до 4000 символов. Более длинные
уведомления MaxNotify автоматически сокращает.

С 19 июля 2026 MAX требует отправлять запросы на домен
`platform-api2.max.ru` вместо `platform-api.max.ru` и добавить сертификат
Минцифры в список доверенных. В MaxNotify новый домен используется по
умолчанию. Если на сервере PHP/cURL не доверяет сертификату системно,
укажите путь к PEM-файлу или CA bundle в настройке
`maxnotify.max_ca_cert_path`.

## Подключение rumaxbot.ru

Установите `maxnotify.provider` в значение `rumaxbot`, затем укажите:

- `maxnotify.api_key` — API-ключ канала rumaxbot.ru;
- `maxnotify.api_url` — адрес API отправки сообщений;

1. Зарегистрируйтесь на rumaxbot.ru и подтвердите email.
2. Создайте канал.
3. Подключите MAX-бота к каналу по инструкции сервиса.
4. Создайте API-ключ канала.
5. Укажите ключ в настройке `maxnotify.api_key`.

API-ключ нельзя публиковать или добавлять в репозиторий.

## Шаблоны сообщений

После установки в категории элементов `MaxNotify` будут созданы чанки:

- `maxNotifyOrderCreated` — новый заказ в Markdown;
- `maxNotifyOrderStatus` — новый статус в Markdown;
- `maxNotifyOrderCreatedHtml` — новый заказ в HTML;
- `maxNotifyOrderStatusHtml` — новый статус в HTML;
- `maxNotifyForm` — заявка с формы в Markdown;
- `maxNotifyFormHtml` — заявка с формы в HTML.

Доступные плейсхолдеры: `num`, `cost`, `receiver`, `phone`, `email`,
`address`, `comment`, `order_comment`, `products`, `delivery_name`,
`payment_name`, `status_name`, `manager_url`, `source`, `title`, `fields`,
`resource_id`, `resource_pagetitle`, `ip` и другие поля заказа или формы.
',
    'changelog' => '# История изменений MaxNotify

## 1.2.0-pl

- добавлены уведомления о заявках FormIt через hook-сниппет `maxNotifyFormIt`;
- добавлены уведомления о заявках SendIt через hook-сниппет `maxNotifySendIt`;
- добавлен общий шаблон заявки `maxNotifyForm` и HTML-версия `maxNotifyFormHtml`;
- добавлены отдельные переключатели источников `maxnotify.enable_minishop2`, `maxnotify.enable_formit`, `maxnotify.enable_sendit`;
- добавлен список исключаемых технических полей формы `maxnotify.form_exclude_fields`;
- добавлены отдельные заголовки уведомлений FormIt и SendIt.

## 1.1.1-pl

- обновлён официальный endpoint MAX Business API на `https://platform-api2.max.ru/messages`;
- добавлена миграция старого значения `platform-api.max.ru` при обновлении пакета;
- добавлена настройка `maxnotify.max_ca_cert_path` для PEM-файла/CA bundle с сертификатом Минцифры;
- обновлена документация по требованию MAX перейти на новый домен до 19 июля 2026.

## 1.1.0-pl

- добавлена прямая интеграция с официальным MAX Business API;
- добавлен выбор провайдера между MAX Business и rumaxbot.ru;
- добавлена отправка в чат, канал или пользователю по `chat_id`/`user_id`;
- добавлена отправка нескольким получателям;
- учтено ограничение официального API в 4000 символов;
- сохранена обратная совместимость с настройками rumaxbot.ru.

## 1.0.1-pl

- добавлены данные доставки, оплаты и полный адрес заказа;
- ссылка в сообщении ведёт непосредственно на заказ в MODX.

## 1.0.0-pl

- первая версия компонента;
- уведомления о новых заказах miniShop2;
- уведомления об изменении статусов;
- интеграция с API rumaxbot.ru;
- шаблоны Markdown и HTML.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '22cc2916a371b0aa262ffa0f61c436c2',
      'native_key' => 'maxnotify',
      'filename' => 'modNamespace/409d4ebb3a7ac06b2e753117bcac2de2.vehicle',
      'namespace' => 'maxnotify',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '906532dcd651815e109568b5126477b0',
      'native_key' => NULL,
      'filename' => 'modCategory/ce37269c1d698aae1828e848c35e5539.vehicle',
      'namespace' => 'maxnotify',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2762a8bb672f7e8b1925eb73f0a7a7b2',
      'native_key' => 'maxnotify.enabled',
      'filename' => 'modSystemSetting/9f7f6653f5f7927026b6d92df2480e52.vehicle',
      'namespace' => 'maxnotify',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6beb35204bd9a2ad63529bc3ffa500f',
      'native_key' => 'maxnotify.enable_minishop2',
      'filename' => 'modSystemSetting/ee4643ffa44a31f6b44f89c5c2725de0.vehicle',
      'namespace' => 'maxnotify',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10156bba3881d05b3178ad11457d16cd',
      'native_key' => 'maxnotify.enable_formit',
      'filename' => 'modSystemSetting/59fabd67fc8e6d872f5718596d7d36b6.vehicle',
      'namespace' => 'maxnotify',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '843765f9f3e0974331d773c429ffc2e0',
      'native_key' => 'maxnotify.enable_sendit',
      'filename' => 'modSystemSetting/ce026652384a80a3c579fab9b2e0bac3.vehicle',
      'namespace' => 'maxnotify',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5cecce96c7c92c0e357ea46173b75005',
      'native_key' => 'maxnotify.provider',
      'filename' => 'modSystemSetting/a1c902b07ea023b3de4cc3191f2517d3.vehicle',
      'namespace' => 'maxnotify',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '216c277c24e165445c39ac313c4c6caa',
      'native_key' => 'maxnotify.api_url',
      'filename' => 'modSystemSetting/cd997e39c364b680919872bbe247d8b5.vehicle',
      'namespace' => 'maxnotify',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47c2f841c8a0020a046b054ae9c081da',
      'native_key' => 'maxnotify.api_key',
      'filename' => 'modSystemSetting/7c9d904bd10c70aae0a556844125eb64.vehicle',
      'namespace' => 'maxnotify',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '095548ae0cc19102f078412f1c4292ef',
      'native_key' => 'maxnotify.max_api_url',
      'filename' => 'modSystemSetting/46b0f2834c8d8bbd11b2694d2d838c18.vehicle',
      'namespace' => 'maxnotify',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e2ffa160b586a4ce91654c041dabd5d',
      'native_key' => 'maxnotify.max_token',
      'filename' => 'modSystemSetting/846b23f505761b4c01554b34bba15e7f.vehicle',
      'namespace' => 'maxnotify',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e8b68f050c4038ee3f067426c064660',
      'native_key' => 'maxnotify.max_ca_cert_path',
      'filename' => 'modSystemSetting/1614de1abf7b9a0c0347df0f9938f79f.vehicle',
      'namespace' => 'maxnotify',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '348091dc8478fb9e225dee49e1470f5c',
      'native_key' => 'maxnotify.max_recipient_type',
      'filename' => 'modSystemSetting/bc2cb649ef9ec3283c43b0dfa73a55f7.vehicle',
      'namespace' => 'maxnotify',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6ccf30f010826e8843b0a5657931f3b',
      'native_key' => 'maxnotify.max_recipient_ids',
      'filename' => 'modSystemSetting/3e994b9b066bbb903dd1cb6dab374011.vehicle',
      'namespace' => 'maxnotify',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24b6cabd2b7fb238922214f5e5b91b6e',
      'native_key' => 'maxnotify.max_notify',
      'filename' => 'modSystemSetting/8a7a6e608b2c9b4a06fcb554201183f2.vehicle',
      'namespace' => 'maxnotify',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b70c92443ab824a87bd99902688487f1',
      'native_key' => 'maxnotify.max_disable_link_preview',
      'filename' => 'modSystemSetting/e02744c8d25963892f2d4ec417c7f6f9.vehicle',
      'namespace' => 'maxnotify',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '988c158032fbdc1ab3e24eaacb7eda93',
      'native_key' => 'maxnotify.format',
      'filename' => 'modSystemSetting/2df7710b9cfd41fa08babce7a6e22e3a.vehicle',
      'namespace' => 'maxnotify',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f315d44ccfb9222675f4d8e00ca0d4c9',
      'native_key' => 'maxnotify.timeout',
      'filename' => 'modSystemSetting/83606a26f4c621433b1be8fca35ab325.vehicle',
      'namespace' => 'maxnotify',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5cf31bce96f84cc9d2289e64158e185',
      'native_key' => 'maxnotify.notify_new_order',
      'filename' => 'modSystemSetting/230f850d9d4e03c7ee85172d17baa174.vehicle',
      'namespace' => 'maxnotify',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6063b402ec0c277d4b82fd1303093cca',
      'native_key' => 'maxnotify.notify_status_change',
      'filename' => 'modSystemSetting/f5367f4be499439a28ca718c4b211840.vehicle',
      'namespace' => 'maxnotify',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c5aff08a04d0f84d30918545b841182',
      'native_key' => 'maxnotify.statuses',
      'filename' => 'modSystemSetting/9732ce48387d36344e2e9ef0add5cc38.vehicle',
      'namespace' => 'maxnotify',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '466cb4d3df26a7251e041c5b1d29d48e',
      'native_key' => 'maxnotify.form_title',
      'filename' => 'modSystemSetting/9f49a099600f8f78a583bcf30d68e497.vehicle',
      'namespace' => 'maxnotify',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92d8f4a875cbab5702532ab490aed06d',
      'native_key' => 'maxnotify.formit_title',
      'filename' => 'modSystemSetting/0e16e07519223cabf72b883ebff6e38b.vehicle',
      'namespace' => 'maxnotify',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba950dfdd036d4fbd6abe8b215ba4e72',
      'native_key' => 'maxnotify.sendit_title',
      'filename' => 'modSystemSetting/37a9fd0788b7aaa50c56b0cd50210388.vehicle',
      'namespace' => 'maxnotify',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15300b6c704d8f8b6ab7f34de80b6d2b',
      'native_key' => 'maxnotify.form_exclude_fields',
      'filename' => 'modSystemSetting/06cf8c4ba236591251a4eeb389dc8d0d.vehicle',
      'namespace' => 'maxnotify',
    ),
  ),
);